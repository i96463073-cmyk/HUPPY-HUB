require("dotenv").config();
const express=require("express");
const path=require("path");
const app=express();
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

const PORT=process.env.PORT||3000;
const DENZ=process.env.DENZGAINS_API_URL||"https://denzgains.com/api/v2";
const PESAPAL=process.env.PESAPAL_ENV==="sandbox"?"https://cybqa.pesapal.com/pesapalv3":"https://pay.pesapal.com/v3";

const orders=new Map();

function id(){return "HH-"+Date.now()+"-"+Math.random().toString(36).slice(2,8).toUpperCase()}

async function pesapalToken(){
  const r=await fetch(`${PESAPAL}/api/Auth/RequestToken`,{method:"POST",headers:{"Accept":"application/json","Content-Type":"application/json"},body:JSON.stringify({consumer_key:process.env.PESAPAL_CONSUMER_KEY,consumer_secret:process.env.PESAPAL_CONSUMER_SECRET})});
  const d=await r.json(); if(!r.ok||!d.token) throw new Error(d.message||"PesaPal authentication failed"); return d.token;
}

app.get("/api/services",async(req,res)=>{
  try{
    const u=`${DENZ}?action=services&key=${encodeURIComponent(process.env.DENZGAINS_API_KEY)}`;
    const r=await fetch(u); const d=await r.json();
    if(!r.ok) return res.status(502).json({success:false,error:"DenzGains services failed",details:d});
    res.json({success:true,services:d});
  }catch(e){res.status(500).json({success:false,error:e.message})}
});

app.post("/api/orders",async(req,res)=>{
  try{
    const {serviceId,link,quantity,amount,firstName,lastName,email,phone}=req.body;
    if(!serviceId||!link||!quantity||!amount||!phone) return res.status(400).json({success:false,error:"Missing required order fields"});
    const merchant=id();
    orders.set(merchant,{merchant,serviceId:String(serviceId),link,quantity:Number(quantity),amount:Number(amount),firstName:firstName||"",lastName:lastName||"",email:email||"",phone,payment:"PENDING",denzOrderId:null});
    const token=await pesapalToken();
    const payload={id:merchant,currency:"KES",amount:Number(amount),description:`HUPPY HUB Order ${merchant}`,callback_url:process.env.PESAPAL_CALLBACK_URL,cancellation_url:process.env.PESAPAL_CANCEL_URL||process.env.PESAPAL_CALLBACK_URL,notification_id:process.env.PESAPAL_IPN_ID,billing_address:{email_address:email||"",phone_number:phone,country_code:"KE",first_name:firstName||"",middle_name:"",last_name:lastName||"",line_1:"",line_2:"",city:"",state:"",postal_code:"",zip_code:""}};
    const r=await fetch(`${PESAPAL}/api/Transactions/SubmitOrderRequest`,{method:"POST",headers:{"Accept":"application/json","Content-Type":"application/json",Authorization:`Bearer ${token}`},body:JSON.stringify(payload)});
    const d=await r.json(); if(!r.ok||!d.redirect_url) return res.status(502).json({success:false,error:d.message||"PesaPal payment creation failed",details:d});
    orders.get(merchant).trackingId=d.order_tracking_id;
    res.json({success:true,orderId:merchant,paymentUrl:d.redirect_url});
  }catch(e){console.error(e);res.status(500).json({success:false,error:e.message})}
});

async function pesapalStatus(trackingId){
  const token=await pesapalToken();
  const r=await fetch(`${PESAPAL}/api/Transactions/GetTransactionStatus?orderTrackingId=${encodeURIComponent(trackingId)}`,{headers:{Accept:"application/json",Authorization:`Bearer ${token}`}});
  const d=await r.json(); if(!r.ok) throw new Error(d.message||"Status lookup failed"); return d;
}

async function sendDenz(order){
  // Confirm the exact Create-tab fields in your DenzGains dashboard before production.
  const body=new URLSearchParams({key:process.env.DENZGAINS_API_KEY,action:"add",service:String(order.serviceId),link:order.link,quantity:String(order.quantity)});
  const r=await fetch(DENZ,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
  return await r.json();
}

async function fulfill(merchant,tracking){
  const order=orders.get(merchant); if(!order) throw new Error("Order not found");
  if(order.payment==="COMPLETED"&&order.denzOrderId) return order;
  const p=await pesapalStatus(tracking);
  const completed=Number(p.status_code)===1||String(p.payment_status_description||"").toUpperCase()==="COMPLETED";
  if(!completed){order.payment=String(p.payment_status_description||"PENDING").toUpperCase();return order}
  order.payment="COMPLETED";
  if(!order.denzOrderId){
    const d=await sendDenz(order);
    if(d&&d.order){order.denzOrderId=String(d.order);order.denzStatus="SUBMITTED"}else{order.denzStatus="ERROR";order.denzResponse=d}
  }
  return order;
}

app.get("/api/pesapal/ipn",async(req,res)=>{
  try{
    const tracking=req.query.OrderTrackingId, merchant=req.query.OrderMerchantReference;
    if(tracking&&merchant) await fulfill(merchant,tracking);
    res.json({orderNotificationType:"IPNCHANGE",orderTrackingId:tracking,orderMerchantReference:merchant,status:200});
  }catch(e){console.error("IPN",e);res.status(500).json({status:500,message:"IPN processing failed"})}
});

app.get("/api/pesapal/callback",async(req,res)=>{
  const tracking=req.query.OrderTrackingId, merchant=req.query.OrderMerchantReference;
  try{if(tracking&&merchant) await fulfill(merchant,tracking)}catch(e){console.error("callback",e)}
  res.redirect(`/payment.html?order=${encodeURIComponent(merchant||"")}`);
});

app.get("/api/orders/:id",(req,res)=>{
  const o=orders.get(req.params.id);
  if(!o) return res.status(404).json({success:false,error:"Order not found"});
  res.json({success:true,order:o});
});

app.get("/payment.html",(req,res)=>res.sendFile(path.join(__dirname,"public","payment.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`HUPPY HUB running on ${PORT}`));

# HUPPY HUB

A plain HTML/CSS/JS frontend with a Node/Express backend for DenzGains + PesaPal.

## Setup
1. Install Node.js 18+.
2. `npm install`
3. Copy `.env.example` to `.env`.
4. Add your PesaPal and DenzGains credentials.
5. Register a public PesaPal IPN URL: `https://YOUR-DOMAIN.com/api/pesapal/ipn`.
6. Put the returned `ipn_id` in `PESAPAL_IPN_ID`.
7. Set `PESAPAL_CALLBACK_URL=https://YOUR-DOMAIN.com/api/pesapal/callback`.
8. Run `npm start`.
9. Open the site.

## Important
The DenzGains Create request is written in the common SMM API format (`action=add`, `service`, `link`, `quantity`). Confirm the exact fields/response in DenzGains API > Create before going live.

Do not put API secrets in `public/app.js`.
